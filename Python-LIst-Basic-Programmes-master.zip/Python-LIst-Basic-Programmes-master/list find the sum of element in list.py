# Programme by parth.py
# Find the sum of elements in list

def sum_ele(lst):
    sum = 0
    for i in lst:
        sum = sum + i
    print(f'Sum of lst elements-:{sum}')


sum_ele([2,3,5,2,5,2,44,3,2,5,22,224,543,5543,4656546,6456456,3456547562,45645645456,2464645])

"""
output:
Sum of lst elements-:19
"""