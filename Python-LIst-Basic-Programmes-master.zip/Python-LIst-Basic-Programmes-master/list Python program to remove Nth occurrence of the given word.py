# Programme by parth.py
# Python program to remove Nth occurrence of the given word

def fun(n):
    lst = ["parth","patel","number"]
    lst.pop(n)
    print(lst)

fun(0)

"""
output:
['patel','number']
"""
