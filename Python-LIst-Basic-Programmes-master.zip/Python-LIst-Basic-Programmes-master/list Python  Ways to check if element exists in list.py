# Programme by parth.py
# Python  Ways to check if element exists in list
def check(n,lst):
    if n in lst:
        print("Elements are available")
    else:
        print("Elements are not available")

check(9,[1,2,3,4,5,6,3])

str1 = 'parth patel'
str = str1.split(" ")
a = '-'.join(str)
print(a)

"""
output:
Element are not available
"""